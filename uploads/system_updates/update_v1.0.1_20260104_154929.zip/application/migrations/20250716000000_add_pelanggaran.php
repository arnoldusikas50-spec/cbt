<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Migration_add_pelanggaran extends CI_Migration {

	public function up() {
        $fieldExist = $this->db->list_fields('cbt_rekap_siswa');
        $fields = [];
        if (!in_array('pelanggaran', $fieldExist)) {
            $fields['pelanggaran'] = ['type' => 'TEXT'];
        }
        if (count($fields) > 0) {
            $this->dbforge->add_column('cbt_rekap_siswa', $fields);
        }
	 }
}