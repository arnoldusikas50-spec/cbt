<!DOCTYPE html>
<html>

<head>

    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?= $judul ?> | CBT by Ikasmedia</title>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <?php $logo_app = $setting->logo_kiri == null ? base_url() . 'assets/img/favicon.png' : base_url() . $setting->logo_kiri; ?>
    <link rel="shortcut icon" href="<?= $logo_app ?>" type="image/x-icon">



    <link rel="stylesheet" href="<?= base_url() ?>assets/app/css/google-fonts.css">
    <!-- Required CSS -->
    <!-- v3 -->
    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/datatables-bs5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet"
        href="<?= base_url() ?>/assets/plugins/datatables-responsive/css/responsive.bootstrap5.min.css">

    <!-- JQVMap -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/jqvmap/jqvmap.min.css">
    <!-- multi select -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/multiselect/css/multi-select.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Datetime picker -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/jquery-datetimepicker/jquery.datetimepicker.min.css">
    <!-- Tempusdominus bootstrap 5 -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/tempus-dominus/tempus-dominus.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/select2/css/select2.min.css">
    <link rel="stylesheet"
        href="<?= base_url() ?>/assets/plugins/select2-bootstrap5-theme/select2-bootstrap-5-theme.min.css">
    <!-- Toastr -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/app/css/jquery.toast.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/toastr/toastr.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/sweetalert2/sweetalert2.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/dropify/css/dropify.min.css">

    <!-- Datatables Buttons -->
    <!-- <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css"> -->

    <!-- fonts -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/adminlte/dist/css/poppins.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/adminlte/dist/css/calibri.css">

    <link rel="stylesheet" href="<?= base_url() ?>/assets/app/css/show.toast.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/adminlte/dist/css/adminlte.min.css">

    <!-- textarea editor -->
    <!-- summernote -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/summernote/summernote-lite.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/summernote/plugin/audio/summernote-audio.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/katex/katex.css">
    <!-- /texarea editor; -->
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url() ?>/assets/app/css/premium_adminlte.css">

    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/DualSelectList/css/bala.DualSelectList.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/app/css/weekCalendar.css">

    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/bootstrap-icon/bootstrap-icons.css">

    <link href="<?= base_url() ?>/assets/plugins/ios-switch/component-custom-switch.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/assets/app/css/player.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="<?= base_url() ?>/assets/plugins/jquery/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?= base_url() ?>/assets/plugins/jquery-ui/jquery-ui.min.js"></script>

    <script type="text/javascript"
        src="<?= base_url() ?>/assets/plugins/DualSelectList/js/bala.DualSelectList.jquery.js"></script>

    <script defer src="<?= base_url() ?>/assets/plugins/katex/contrib/auto-render.min.js"
        onload="renderMathInElement(document.body);"></script>
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/app/css/stylised.css">
    <link rel="stylesheet" href="<?= base_url() ?>/assets/plugins/contextmenu/jquery.contextmenu.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/plugins/fields-linker/fieldsLinker.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/plugins/pignose/css/pignose.calendar.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/app/css/new-upload.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>/assets/app/css/custom-correction.css">


    <style>
        page {
            background: white;
            display: block;
            margin: 0 auto;
            margin-bottom: 0.5cm;
            box-shadow: none;
        }

        page[size="A4"][layout="potrait"] {
            width: 21cm;
            height: 29.7cm;
        }

        page[size="A4"] {
            width: 29.7cm;
            height: 21cm;
        }

        .linker-list p {
            margin-bottom: .5rem;
            margin-top: .5rem;
        }
    </style>
</head>
<script>
    let base_url = '<?= base_url() ?>';
    let globalToken;
    let adaJadwalUjian;
    $(document).ready(function () {
        // cek update
        const page = '<?= $this->uri->segment(1) ?>';
        if (page !== 'dashboard') {
            $.ajax({
                url: base_url + "dashboard/check_version",
                type: "GET",
                success: function (response) {
                    if (!response.is_latest) {
                        window.location.href = base_url + 'dashboard/need_update'
                    }
                },
                error: function (xhr, status, error) {
                    console.log(xhr);
                }
            });
        }
    });
</script>
<script src="<?= base_url() ?>/assets/app/js/generate.js"></script>
<script type="text/javascript">
    let tp_active = '<?= isset($tp_active) ? $tp_active->tahun : "" ?>';
    let smt_active = '<?= isset($smt_active) ? $smt_active->smt : "" ?>';
    let id_tp_active = '<?= isset($tp_active) ? $tp_active->id_tp : "" ?>';
    let id_smt_active = '<?= isset($smt_active) ? $smt_active->id_smt : "" ?>';

    function startTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        m = checkTime(m);
        s = checkTime(s);

        $('#live-clock').html('<span class="text-lg">' + h + ':' + m + '</span>:' + s);
        setTimeout(startTime, 1000);
    }

    function checkTime(i) {
        if (i < 10) {
            i = "0" + i
        }
        return i;
    }

    function buat_tanggal_indonesia(str) {
        str = str.replace("Jan", "Januari");
        str = str.replace("Feb", "Februari");
        str = str.replace("Mar", "Maret");
        str = str.replace("Apr", "April");
        str = str.replace("May", "Mei");
        str = str.replace("Jun", "Juni");
        str = str.replace("Jul", "Juli");
        str = str.replace("Aug", "Agustus");
        str = str.replace("Sep", "September");
        str = str.replace("Oct", "Oktober");
        str = str.replace("Nov", "Nopember");
        str = str.replace("Dec", "Desember");
        str = str.replace("Mon", "Senin");
        str = str.replace("Tue", "Selasa");
        str = str.replace("Wed", "Rabu");
        str = str.replace("Thu", "Kamis");
        str = str.replace("Fri", "Jumat");
        str = str.replace("Sat", "Sabtu");
        str = str.replace("Sun", "Minggu");
        return str;
    }

    function sanitizeJSON(unsanitized) {
        return unsanitized.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f").replace(/"/g, "\\\"").replace(/'/g, "\\\'").replace(/\&/g, "\\&");
    }

    var bulans = ['Januari', 'Februari', 'Maret', 'April',
        'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    var arrhari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum\'at', 'Sabtu'];

    function stringToDate(dateStr) {
        var parts = dateStr.split("-");
        return new Date(parts[0], parts[1] - 1, parts[2])
    }

    function dateToString(date) {
        let year = date.getFullYear();
        //let month = (1 + date.getMonth()).toString().padStart(2, '0');
        const month = date.getMonth();
        let day = date.getDate().toString().padStart(2, '0');
        return day + ' ' + bulans[month] + ' ' + year;
    }

    function dateToStringDay(date) {
        let year = date.getFullYear();
        //let month = (1 + date.getMonth()).toString().padStart(2, '0');
        const month = date.getMonth();
        let day = date.getDate().toString().padStart(2, '0');
        return arrhari[date.getDay()] + ', ' + day + ' ' + bulans[month] + ' ' + year;
    }
</script>

<?php

if (!function_exists('buat_tanggal')) {
    function buat_tanggal($str)
    {
        $str = str_replace("Jan", "Januari", $str);
        $str = str_replace("Feb", "Februari", $str);
        $str = str_replace("Mar", "Maret", $str);
        $str = str_replace("Apr", "April", $str);
        $str = str_replace("May", "Mei", $str);
        $str = str_replace("Jun", "Juni", $str);
        $str = str_replace("Jul", "Juli", $str);
        $str = str_replace("Aug", "Agustus", $str);
        $str = str_replace("Sep", "September", $str);
        $str = str_replace("Oct", "Oktober", $str);
        $str = str_replace("Nov", "Nopember", $str);
        $str = str_replace("Dec", "Desember", $str);
        $str = str_replace("Mon", "Senin", $str);
        $str = str_replace("Tue", "Selasa", $str);
        $str = str_replace("Wed", "Rabu", $str);
        $str = str_replace("Thu", "Kamis", $str);
        $str = str_replace("Fri", "Jum'at", $str);
        $str = str_replace("Sat", "Sabtu", $str);
        $str = str_replace("Sun", "Minggu", $str);
        return $str;
    }
}

if (!function_exists('singkat_tanggal')) {
    function singkat_tanggal($str)
    {
        $str = str_replace("Jan", "Jan", $str);
        $str = str_replace("Feb", "Feb", $str);
        $str = str_replace("Mar", "Mar", $str);
        $str = str_replace("Apr", "Apr", $str);
        $str = str_replace("May", "Mei", $str);
        $str = str_replace("Jun", "Jun", $str);
        $str = str_replace("Jul", "Jul", $str);
        $str = str_replace("Aug", "Agt", $str);
        $str = str_replace("Sep", "Sep", $str);
        $str = str_replace("Oct", "Okt", $str);
        $str = str_replace("Nov", "Nov", $str);
        $str = str_replace("Dec", "Des", $str);
        $str = str_replace("Mon", "Senin", $str);
        $str = str_replace("Tue", "Selasa", $str);
        $str = str_replace("Wed", "Rabu", $str);
        $str = str_replace("Thu", "Kamis", $str);
        $str = str_replace("Fri", "Jum'at", $str);
        $str = str_replace("Sat", "Sabtu", $str);
        $str = str_replace("Sun", "Minggu", $str);
        return $str;
    }
}

?>

<body class="layout-fixed layout-navbar-fixed layout-footer-fixed sidebar-expand-lg bg-body-tertiary text-sm"
    onload="startTime()">
    <?php
    $tp_skrg = $tp_sekarang ?? '-';
    $smt_skrg = $smt_sekarang ?? '-';
    if (isset($tp_active) && isset($smt_active) && ($tp_skrg != $tp_active->tahun || $smt_skrg != $smt_active->id_smt)): ?>
        <div class="alert alert-default-danger alert-dismissible fade show fixed-top shadow-sm text-center mb-0 rounded-0"
            role="alert" style="z-index: 1050;">
            <strong>Perhatian!</strong> Tahun ajaran telah berganti ke <?= $tp_sekarang ?? '-' ?>, Semester
            <?= $smt_sekarang ?? '-' ?>.
            <a href="<?= base_url('datatahun') ?>" class="alert-link">Atur Tahun Pelajaran dan Semester</a>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup">

            </button>
        </div>
    <?php endif; ?>
    <div class="app-wrapper">

        <!-- Navbar -->
        <?php require_once("navbar.php"); ?>

        <!-- Sidebar -->
        <?php require_once("sidebar.php"); ?>
        <!-- /.sidebar -->