<main class="app-main bg-white pt-4">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $judul ?></h1>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="card card-default my-shadow">
                <?= form_open('', array('id' => 'create')) ?>
                <div class="card-header with-border">
                    <h3 class="card-title"><?= $subjudul ?></h3>
                    <button type="submit" class="btn btn-primary btn-sm card-tools ms-auto">
                        <i class="bi bi-save me-1"></i>Simpan
                    </button>
                </div>
                <div class="card-body">
                    <div class="row">
                        <input type="hidden" name="id_kelas" value="<?= $id_kelas ?>">
                        <?php
                        $inputs = [
                            'Ketua Kelas',
                            'Wakil Ketua',
                            'Sekretaris 1',
                            'Sekretaris 2',
                            'Bendahara 1',
                            'Bendahara 2',
                            'Sie Ekstrakurikuler',
                            'Sie Upacara',
                            'Sie Olahraga',
                            'Sie Keagamaan',
                            'Sie Keamanan',
                            'Sie Ketertiban',
                            'Sie Kebersihan',
                            'Sie Keindahan',
                            'Sie Kesehatan',
                            'Sie Kekeluargaan',
                            'Sie Humas'
                        ];
                        $ids = ['ketua', 'wakil_ketua', 'sekretaris_1', 'sekretaris_2', 'bendahara_1', 'bendahara_2', 'sie_ekstrakurikuler', 'sie_upacara', 'sie_olahraga', 'sie_keagamaan', 'sie_keamanan', 'sie_ketertiban', 'sie_kebersihan', 'sie_keindahan', 'sie_kesehatan', 'sie_kekeluargaan', 'sie_humas'];

                        //var_dump($struktur);
                        foreach ($ids as $key => $value): ?>
                            <div class="col-md-6 mb-3">
                                <label><i class="bi bi-user me-2"></i><?= $inputs[$key] ?></label>
                                <?php
                                echo form_dropdown(
                                    $value,
                                    $siswas,
                                    $struktur->$value,
                                    'id="' . $value . '" class="select2 form-control" data-placeholder="Pilih ' . $inputs[$key] . '" required'
                                ); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </section>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            ajaxcsrf();

            $('.select2').select2({ width: '100%', });

            $('#create').submit('click', function (e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                console.log("data:", $(this).serialize());
                $.ajax({
                    url: base_url + "walistruktur/save",
                    type: "POST",
                    dataType: "JSON",
                    data: $(this).serialize(),
                    success: function (data) {
                        if (data) {
                            Swal.fire({
                                title: "Sukses",
                                text: "Data berhasil disimpan",
                                icon: "success",
                                showCancelButton: false,
                            }).then(result => {
                                if (result.value) {
                                    window.location.href = base_url + 'walistruktur';
                                }
                            });
                        } else {
                            Swal.fire({
                                title: "ERROR",
                                text: "Data Tidak Tersimpan",
                                icon: "error",
                                showCancelButton: false,
                            });
                        }
                    }, error: function (xhr, status, error) {
                        console.log("error", xhr.responseText);
                        Swal.fire({
                            title: "ERROR",
                            text: "Data Tidak Tersimpan",
                            icon: "error",
                            showCancelButton: false,
                        });
                    }
                });
            });

        });
    </script>