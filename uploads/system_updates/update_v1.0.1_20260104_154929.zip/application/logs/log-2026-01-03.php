<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-03 00:04:47 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 00:30:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 00:55:12 --> Query error: Unknown column 'status' in 'field list' - Invalid query: SELECT `id_jenis`, `nama_jenis`, `kode_jenis`, `status`
FROM `cbt_jenis`
ERROR - 2026-01-03 00:55:16 --> Query error: Unknown column 'status' in 'field list' - Invalid query: SELECT `id_jenis`, `nama_jenis`, `kode_jenis`, `status`
FROM `cbt_jenis`
ERROR - 2026-01-03 00:55:49 --> Query error: Unknown column 'status' in 'field list' - Invalid query: SELECT `id_jenis`, `nama_jenis`, `kode_jenis`, `status`
FROM `cbt_jenis`
ERROR - 2026-01-03 00:56:56 --> Query error: Unknown column 'status' in 'field list' - Invalid query: UPDATE `cbt_jenis` SET `status` = '1'
WHERE `id_jenis` = '7'
ERROR - 2026-01-03 00:57:08 --> Query error: Unknown column 'status' in 'field list' - Invalid query: SELECT `id_jenis`, `nama_jenis`, `kode_jenis`, `status`
FROM `cbt_jenis`
ERROR - 2026-01-03 01:08:55 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 01:19:17 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 01:20:11 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 01:22:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 01:22:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 01:28:45 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 01:28:45 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:28:45 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:28:45 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:28:45 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:28:45 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 01:28:49 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 01:28:49 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:28:49 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:28:49 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:28:49 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:28:49 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 01:28:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 01:29:26 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 01:29:26 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:29:26 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:29:26 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:29:26 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:29:26 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 01:29:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 01:30:10 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 01:30:10 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:30:10 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:30:10 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:30:10 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:30:10 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 01:30:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 01:30:12 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 01:30:12 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:30:12 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 01:30:12 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:30:12 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 01:30:12 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 01:30:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 09:01:29 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 09:08:24 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 09:13:00 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 09:13:09 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 09:13:19 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 09:13:21 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 09:13:44 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 09:13:50 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 09:33:56 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 09:47:12 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 09:54:38 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 09:54:40 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 10:16:22 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 10:16:22 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 10:16:22 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 10:16:22 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 10:16:22 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 10:16:22 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 10:16:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 10:24:44 --> Severity: error --> Exception: Call to undefined method Cbt_model::getAllMapel() D:\wwwroot\server.id\akm\application\controllers\Laporan.php 83
ERROR - 2026-01-03 10:24:48 --> Severity: error --> Exception: Call to undefined method Cbt_model::getAllMapel() D:\wwwroot\server.id\akm\application\controllers\Laporan.php 83
ERROR - 2026-01-03 10:40:25 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:41:42 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:41:42 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:41:42 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:41:42 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:41:42 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:07 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:42:24 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:24 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:24 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:24 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:30 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:42:30 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 10:42:30 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:30 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:30 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:42:30 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:45:52 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:45:53 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:45:53 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:45:53 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 10:46:01 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:46:01 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 10:51:18 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:51:18 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 10:52:39 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Laporan.php 264
ERROR - 2026-01-03 10:52:39 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:10:45 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:11:41 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:12:06 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:14:11 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:15:35 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:16:38 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 11:16:45 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 11:17:32 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 11:17:32 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 11:17:32 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 11:17:32 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 11:17:32 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 11:17:32 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 11:17:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 11:19:31 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:25:34 --> Query error: Unknown column 'no_peserta' in 'field list' - Invalid query: SELECT `id_siswa`, `nama`, `no_peserta`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:25:37 --> Query error: Unknown column 'no_peserta' in 'field list' - Invalid query: SELECT `id_siswa`, `nama`, `no_peserta`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:26:14 --> Query error: Unknown column 'no_peserta' in 'field list' - Invalid query: SELECT `id_siswa`, `nama`, `no_peserta`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:27:30 --> Query error: Unknown column 'no_peserta' in 'field list' - Invalid query: SELECT `id_siswa`, `nama`, `no_peserta`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:27:31 --> Query error: Unknown column 'no_peserta' in 'field list' - Invalid query: SELECT `id_siswa`, `nama`, `no_peserta`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:29:41 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `id_siswa`, `nama`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:29:42 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `id_siswa`, `nama`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:29:43 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `id_siswa`, `nama`, `username`
FROM `master_siswa`
WHERE `status` = '1'
ORDER BY `nama` ASC
ERROR - 2026-01-03 11:30:39 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:30:43 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:31:13 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:37:37 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:38:33 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:38:43 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:38:44 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:39:55 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:39:56 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:40:28 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:40:57 --> Query error: Unknown column 'a.id_mapel' in 'field list' - Invalid query: SELECT `a`.`id_jadwal`, `a`.`id_mapel`, `b`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `master_mapel` `b` ON `b`.`id_mapel` = `a`.`id_mapel`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `a`.`id_mapel`
ORDER BY `b`.`nama_mapel` ASC
ERROR - 2026-01-03 11:42:10 --> Query error: Unknown column 'a.status_jadwal' in 'where clause' - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:42:19 --> Query error: Unknown column 'a.status_jadwal' in 'where clause' - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:42:19 --> Query error: Unknown column 'a.status_jadwal' in 'where clause' - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status_jadwal` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:43:07 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'akm.a.id_jadwal' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:43:09 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'akm.a.id_jadwal' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:43:27 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'akm.a.id_jadwal' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:43:28 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'akm.a.id_jadwal' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `a`.`id_jadwal`, `c`.`id_mapel`, `c`.`nama_mapel`
FROM `cbt_jadwal` `a`
LEFT JOIN `cbt_bank_soal` `b` ON `b`.`id_bank` = `a`.`id_bank`
LEFT JOIN `master_mapel` `c` ON `c`.`id_mapel` = `b`.`bank_mapel_id`
WHERE `a`.`id_tp` = '4'
AND `a`.`id_smt` = '1'
AND `a`.`status` = '1'
GROUP BY `c`.`id_mapel`
ORDER BY `c`.`nama_mapel` ASC
ERROR - 2026-01-03 11:44:11 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:45:27 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 11:45:27 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 11:45:27 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 11:45:27 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 11:47:03 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 11:47:04 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 11:50:06 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 11:50:24 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 11:57:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 12:01:53 --> Severity: Warning --> Attempt to read property "nama" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 8
ERROR - 2026-01-03 12:01:53 --> Severity: Warning --> Attempt to read property "nisn" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 12:01:53 --> Severity: Warning --> Attempt to read property "kode_kelas" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 9
ERROR - 2026-01-03 12:01:53 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 12:01:53 --> Severity: Warning --> Attempt to read property "foto" on null D:\wwwroot\server.id\akm\application\views\members\siswa\templates\top.php 15
ERROR - 2026-01-03 12:01:53 --> Severity: Warning --> Attempt to read property "id_siswa" on null D:\wwwroot\server.id\akm\application\views\members\siswa\cbt\data_jadwal.php 151
ERROR - 2026-01-03 12:01:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 12:10:20 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:24:03 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:24:03 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:24:03 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:24:03 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:24:07 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:24:09 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:36:11 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:39:12 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:39:12 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:39:12 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:39:12 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:39:12 --> 404 Page Not Found: Uploads/laporan
ERROR - 2026-01-03 12:39:17 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:42:50 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:43:35 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:45:18 --> Severity: Warning --> Undefined property: Laporan::$cbt D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:45:18 --> Severity: error --> Exception: Call to a member function getSettingKopBeritaAcara() on null D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:46:19 --> Severity: Warning --> Undefined property: Laporan::$cbt D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:46:19 --> Severity: error --> Exception: Call to a member function getSettingKopBeritaAcara() on null D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:47:35 --> Severity: Warning --> Undefined property: Laporan::$cbt D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:47:35 --> Severity: error --> Exception: Call to a member function getSettingKopBeritaAcara() on null D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:47:56 --> Severity: Warning --> Undefined property: Laporan::$cbt D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:47:56 --> Severity: error --> Exception: Call to a member function getSettingKopBeritaAcara() on null D:\wwwroot\server.id\akm\application\controllers\Laporan.php 372
ERROR - 2026-01-03 12:48:53 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 12:51:01 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 12:52:57 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 12:55:01 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:55:09 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 12:56:08 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:56:11 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 12:56:28 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 12:56:56 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 12:57:47 --> 404 Page Not Found: Uploads/ttd
ERROR - 2026-01-03 16:57:13 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 16:57:18 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 17:04:59 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 17:05:12 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 17:14:39 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 17:16:48 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 17:27:06 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 17:29:51 --> 404 Page Not Found: Uploads/foto_panitia
ERROR - 2026-01-03 20:15:44 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 21:40:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:40:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:41:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:41:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:41:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:41:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:42:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:42:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:43:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:44:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:46:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:46:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:46:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:47:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 21:52:06 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 21:52:08 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 21:52:20 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 21:52:29 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 21:52:47 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 22:00:34 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 22:04:53 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 22:05:04 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-03 22:05:30 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 22:05:45 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 22:07:37 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 22:08:31 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 22:11:18 --> Query error: Table 'akm.cbt_jenis_ujian' doesn't exist - Invalid query: SELECT *
FROM `cbt_jenis_ujian`
WHERE `status` = '1'
ERROR - 2026-01-03 22:26:00 --> 404 Page Not Found: 2023305/index
ERROR - 2026-01-03 22:26:00 --> 404 Page Not Found: 2023305/index
ERROR - 2026-01-03 22:26:02 --> 404 Page Not Found: 2023310/index
ERROR - 2026-01-03 22:26:02 --> 404 Page Not Found: 2023310/index
ERROR - 2026-01-03 22:26:03 --> 404 Page Not Found: 2023310/index
ERROR - 2026-01-03 22:26:03 --> 404 Page Not Found: 2023310/index
ERROR - 2026-01-03 22:26:04 --> 404 Page Not Found: 2023311/index
ERROR - 2026-01-03 22:26:04 --> 404 Page Not Found: 2023311/index
ERROR - 2026-01-03 22:26:05 --> 404 Page Not Found: 2023342/index
ERROR - 2026-01-03 22:26:06 --> 404 Page Not Found: 2023342/index
ERROR - 2026-01-03 22:27:46 --> 404 Page Not Found: 2023302/index
ERROR - 2026-01-03 22:27:46 --> 404 Page Not Found: 2023302/index
ERROR - 2026-01-03 22:46:19 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2026-01-03 23:06:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 23:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-03 23:13:32 --> Severity: Warning --> Undefined property: stdClass::$aplikasi D:\wwwroot\server.id\akm\application\views\auth\login_new_staff.php 331
ERROR - 2026-01-03 23:13:38 --> Severity: Warning --> Undefined property: stdClass::$aplikasi D:\wwwroot\server.id\akm\application\views\auth\login_new_staff.php 331
ERROR - 2026-01-03 23:13:50 --> Severity: Warning --> Undefined property: stdClass::$aplikasi D:\wwwroot\server.id\akm\application\views\auth\login_new_staff.php 331
ERROR - 2026-01-03 23:56:30 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:56:30 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:56:34 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:56:42 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:56:44 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:56:57 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:56:58 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:57:00 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:32 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:32 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:32 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:39 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:40 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:43 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:58:44 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:59:11 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:59:18 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:59:22 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:59:23 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-03 23:59:26 --> 404 Page Not Found: Assets/img
