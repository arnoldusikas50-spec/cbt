<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-25 03:48:59 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:49:03 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:49:03 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:50:01 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:50:27 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:50:55 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:51:13 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:53:47 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:53:54 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:53:59 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:54:41 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:54:46 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:56:21 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 03:56:25 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 04:05:49 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 04:05:50 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:05:55 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:05:56 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:07 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:08 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:08 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:09 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:28 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:29 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:06:29 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:07:32 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:07:33 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:07:34 --> Severity: error --> Exception: Call to undefined method CI_Loader::maybe_unserialize() D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 286
ERROR - 2025-12-25 04:07:39 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\application\controllers\Rpm.php 39
ERROR - 2025-12-25 04:07:41 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\application\controllers\Rpm.php 39
ERROR - 2025-12-25 04:07:51 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\application\controllers\Rpm.php 39
ERROR - 2025-12-25 04:07:52 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\application\controllers\Rpm.php 39
ERROR - 2025-12-25 04:08:35 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\application\controllers\Rpm.php 39
ERROR - 2025-12-25 04:08:36 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\application\controllers\Rpm.php 39
ERROR - 2025-12-25 08:26:44 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:28:50 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:28:51 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:28:51 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:29:00 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:29:00 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:29:23 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:29:23 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:30:04 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:30:04 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:30:41 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:30:46 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:30:46 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:31:17 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:31:17 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:31:45 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:31:45 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:31:53 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:32:39 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:32:39 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:34:20 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:34:20 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:34:22 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:34:22 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:34:37 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:34:37 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:34:53 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:34:53 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:35:27 --> Severity: Notice --> Trying to get property 'nama_lengkap' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2025-12-25 08:35:27 --> Severity: Notice --> Trying to get property 'jabatan' of non-object D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2025-12-25 08:37:06 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:50:18 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:54:16 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:57:08 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 08:57:30 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:03:56 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:06:35 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:06:41 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:06:45 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:06:56 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:12:10 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:13:19 --> 404 Page Not Found: Cbtguru/index
ERROR - 2025-12-25 09:15:22 --> 404 Page Not Found: Cbtguru/index
ERROR - 2025-12-25 09:16:10 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:16:13 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:16:58 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:24 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:25 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:32 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:38 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:43 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:52 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:17:55 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:05 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:07 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:10 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:38 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:39 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:40 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:19:41 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:20:11 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:20:26 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:20:41 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:20:52 --> Severity: Notice --> Trying to get property 'id_jabatan' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\templates\sidebar.php 31
ERROR - 2025-12-25 09:21:46 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:32:13 --> Severity: Notice --> Undefined variable: gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 73
ERROR - 2025-12-25 09:34:46 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 09:44:14 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 10:07:31 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 10:07:48 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 10:09:04 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 10:09:07 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 10:42:04 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 11:03:28 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 11:04:43 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 11:35:09 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 11:35:13 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 11:38:20 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 11:53:37 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 12:49:38 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 13:03:55 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 13:19:33 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 13:19:40 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 13:19:48 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 14:09:14 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 14:09:19 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 14:09:25 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 14:43:33 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 15:47:57 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 22:17:35 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'nama_guru' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 22
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'level' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 23
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'nama_kelas' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 23
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'id_guru' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 104
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'foto' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 251
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'id_guru' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 286
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'username' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 302
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'password' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 309
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'id_guru' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 349
ERROR - 2025-12-25 22:20:51 --> Severity: Notice --> Trying to get property 'foto' of non-object D:\wwwroot\server.id\akm\application\views\members\guru\profile.php 350
ERROR - 2025-12-25 22:22:32 --> 404 Page Not Found: Assets/img
