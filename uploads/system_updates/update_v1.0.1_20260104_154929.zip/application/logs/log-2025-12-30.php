<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-30 08:56:04 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 08:56:06 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 08:56:30 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 08:56:38 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 08:56:43 --> 404 Page Not Found: Assets/app
ERROR - 2025-12-30 08:56:50 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 08:57:33 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 08:57:37 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 10:12:26 --> 404 Page Not Found: %3C/index
ERROR - 2025-12-30 10:12:34 --> 404 Page Not Found: %3C/index
ERROR - 2025-12-30 10:12:48 --> 404 Page Not Found: %3C/index
ERROR - 2025-12-30 10:54:46 --> 404 Page Not Found: Admin/index
ERROR - 2025-12-30 10:59:26 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 10:59:36 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 11:01:01 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 11:04:07 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 11:07:08 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 11:36:09 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-30 12:28:57 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-30 12:32:54 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-30 14:19:39 --> 404 Page Not Found: Ujianhtml/index
ERROR - 2025-12-30 15:51:00 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-30 15:51:04 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-30 15:51:07 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-30 18:24:17 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:24:29 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:24:35 --> 404 Page Not Found: Assets/app
ERROR - 2025-12-30 18:24:39 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:24:42 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:37:14 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:37:20 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:37:56 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:38:09 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:38:52 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 18:39:29 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:40:08 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:40:58 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:41:46 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:42:00 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:42:20 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:42:52 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:43:06 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:44:56 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:45:32 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:47:12 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:48:24 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:49:30 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:50:53 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:50:59 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:51:13 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:51:16 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:51:30 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:52:02 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:54:07 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:54:46 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 18:55:15 --> 404 Page Not Found: Jawab/index
ERROR - 2025-12-30 19:00:47 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:05 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:13 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:45 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:50 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:55 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:57 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:01:59 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:01 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:05 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:09 --> 404 Page Not Found: Assets/app
ERROR - 2025-12-30 19:02:11 --> 404 Page Not Found: Assets/app
ERROR - 2025-12-30 19:02:14 --> 404 Page Not Found: Assets/app
ERROR - 2025-12-30 19:02:18 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:26 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:32 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:52 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:02:54 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:03 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:14 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:19 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:23 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:25 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:29 --> 404 Page Not Found: Assets/app
ERROR - 2025-12-30 19:03:31 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:36 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:40 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:42 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:03:48 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:04:00 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:04:07 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:05:29 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:05:34 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:05:36 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 19:28:14 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 19:28:38 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:05 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:05 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:05 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:05 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:06:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:07:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:09:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:09:51 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 20:10:42 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:10:47 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1425
ERROR - 2025-12-30 20:11:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 121
ERROR - 2025-12-30 20:25:57 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:34:37 --> Severity: Warning --> Undefined property: stdClass::$jawaban D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1701
ERROR - 2025-12-30 20:34:37 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1701
ERROR - 2025-12-30 20:38:37 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:39:06 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:40:48 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:40:54 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:40:57 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:40:59 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:41:02 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:41:04 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:41:07 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 20:51:16 --> Severity: Warning --> Undefined property: stdClass::$jawaban D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1701
ERROR - 2025-12-30 20:51:16 --> Severity: 8192 --> json_decode(): Passing null to parameter #1 ($json) of type string is deprecated D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1701
ERROR - 2025-12-30 21:24:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:28:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:29:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:29:07 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 21:29:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:29:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:29:11 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 21:29:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:29:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:29:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:31:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:33:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:34:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:34:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:34:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:34:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:37:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:38:11 --> 404 Page Not Found: Ujianhtml/index
ERROR - 2025-12-30 21:38:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:39:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:40:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:40:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:40:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:40:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:42:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:45:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:45:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 21:45:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:19:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:20:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:20:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:21:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:31:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:35:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:41:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:41:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:43:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:47:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:52:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:52:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:52:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:52:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:53:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:55:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:55:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:55:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:55:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:56:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:56:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 22:58:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 23:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 23:20:44 --> 404 Page Not Found: 20250393/index
ERROR - 2025-12-30 23:20:44 --> 404 Page Not Found: 20250390/index
ERROR - 2025-12-30 23:55:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 23:55:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 23:55:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 23:55:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2025-12-30 23:55:52 --> 404 Page Not Found: Assets/plugins
