<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-29 20:34:48 --> 404 Page Not Found: Admin/index
