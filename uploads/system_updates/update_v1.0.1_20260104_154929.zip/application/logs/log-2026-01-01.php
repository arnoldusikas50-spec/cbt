<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-01 01:14:59 --> 404 Page Not Found: 20250390/index
ERROR - 2026-01-01 01:20:15 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-01 01:25:38 --> 404 Page Not Found: 20250390/index
ERROR - 2026-01-01 01:29:22 --> 404 Page Not Found: 20250390/index
ERROR - 2026-01-01 10:16:29 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-01 10:43:09 --> Severity: Warning --> Undefined property: stdClass::$name D:\wwwroot\server.id\akm\application\views\master\guru\edit.php 201
ERROR - 2026-01-01 10:43:09 --> Severity: Warning --> Undefined property: stdClass::$name D:\wwwroot\server.id\akm\application\views\master\guru\edit.php 211
ERROR - 2026-01-01 10:43:09 --> Severity: Warning --> Undefined property: stdClass::$name D:\wwwroot\server.id\akm\application\views\master\guru\edit.php 212
ERROR - 2026-01-01 10:43:36 --> Severity: Warning --> Undefined property: stdClass::$name D:\wwwroot\server.id\akm\application\views\master\guru\edit.php 201
ERROR - 2026-01-01 10:43:36 --> Severity: Warning --> Undefined property: stdClass::$name D:\wwwroot\server.id\akm\application\views\master\guru\edit.php 211
ERROR - 2026-01-01 10:43:36 --> Severity: Warning --> Undefined property: stdClass::$name D:\wwwroot\server.id\akm\application\views\master\guru\edit.php 212
ERROR - 2026-01-01 10:52:42 --> 404 Page Not Found: Uploads/profile_guru
ERROR - 2026-01-01 10:52:42 --> 404 Page Not Found: Uploads/profile_guru
ERROR - 2026-01-01 10:54:58 --> 404 Page Not Found: 2023303/index
ERROR - 2026-01-01 10:54:58 --> 404 Page Not Found: 2023303/index
ERROR - 2026-01-01 13:32:26 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 72
ERROR - 2026-01-01 13:45:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:45:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 13:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:00:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:06:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:06:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:06:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:06:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 14:07:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:21:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:22:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:23:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:24:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:25:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:26:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:26:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:26:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:26:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:27:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:27:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:29:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:29:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:29:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:29:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:30:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:30:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:31:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:31:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:33:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:33:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:33:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:33:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:34:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:35:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:35:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:36:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:36:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:36:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:36:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:36:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:36:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:38:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:39:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:39:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:39:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:39:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:42:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:42:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:42:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:42:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:43:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:43:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:43:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:43:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:43:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:43:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:44:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:45:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:45:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:45:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:45:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:46:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:46:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:46:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:46:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:46:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:46:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:47:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:47:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:47:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:47:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:49:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:52:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:52:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:52:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:52:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 19:59:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:00:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:03:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:03:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:03:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:03:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:06:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:09:54 --> 404 Page Not Found: Cbtstatus/belumujian
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:10:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:10:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:10:07 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtstatus.php 714
ERROR - 2026-01-01 20:10:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:10:37 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:37 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:10:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:10:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtstatus.php 714
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:17 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:11:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:11:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:11:18 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtstatus.php 714
ERROR - 2026-01-01 20:11:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:11:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:11:33 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:11:34 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtstatus.php 714
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:04 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:12:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtstatus.php 714
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:12:21 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:12:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:12:21 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtstatus.php 714
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:13:30 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:13:31 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\system\database\DB_query_builder.php 838
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:09 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:09 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\system\database\DB_query_builder.php 838
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:31 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:31 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\system\database\DB_query_builder.php 838
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:14:36 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:14:36 --> Severity: error --> Exception: Object of class stdClass could not be converted to string D:\wwwroot\server.id\akm\system\database\DB_query_builder.php 838
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:15:47 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:16:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:10 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:38 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:39 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:17:43 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:17:44 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:47:23 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:47:24 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:50:24 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:50:25 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:53:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:54:13 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:54:13 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:55:16 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:07 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:07 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:56:08 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:56:08 --> Query error: Unknown column 'a.id_kelas' in 'field list' - Invalid query: SELECT `a`.`id_siswa`, `a`.`nama`, `a`.`nis`, `b`.`nama_kelas`, `c`.`nama_ruang`, `d`.`nama_sesi`, `a`.`id_kelas`, `e`.`ruang_id`, `e`.`sesi_id`
FROM `master_siswa` `a`
JOIN `master_kelas` `b` ON `b`.`id_kelas`=`a`.`id_kelas`
LEFT JOIN `cbt_sesi_siswa` `e` ON `e`.`siswa_id`=`a`.`id_siswa`
LEFT JOIN `cbt_ruang` `c` ON `c`.`id_ruang`=`e`.`ruang_id`
LEFT JOIN `cbt_sesi` `d` ON `d`.`id_sesi`=`e`.`sesi_id`
WHERE `a`.`id_kelas` IN('18', '19')
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:10 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:34 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 20:59:59 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:28 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:00:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:00 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 44
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 45
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:01:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:06 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:22 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:26 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:03:58 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:51 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:04:54 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 57
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 58
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 70
ERROR - 2026-01-01 21:06:32 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 71
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 55
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_kelas" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 56
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "id_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 68
ERROR - 2026-01-01 21:06:55 --> Severity: Warning --> Attempt to read property "nama_ruang" on string D:\wwwroot\server.id\akm\application\views\members\panitia\cbt\status\belum_ujian.php 69
ERROR - 2026-01-01 22:06:33 --> Query error: Unknown column 'jenis_kelamin' in 'field list' - Invalid query: UPDATE `master_panitia` SET `nama_panitia` = 'Panitia Test', `nip` = '197904082008012029', `email` = 'randyikas@gmail.com', `no_hp` = '085339035155', `instansi` = 'SMA', `ruang` = '', `jenis_kelamin` = 'L', `agama` = 'Islam', `api_key` = ''
WHERE `id_panitia` = '3'
ERROR - 2026-01-01 22:06:39 --> Query error: Unknown column 'jenis_kelamin' in 'field list' - Invalid query: UPDATE `master_panitia` SET `nama_panitia` = 'Panitia Test', `nip` = '197904082008012029', `email` = 'randyikas@gmail.com', `no_hp` = '085339035155', `instansi` = 'SMA', `ruang` = '', `jenis_kelamin` = 'L', `agama` = 'Islam', `api_key` = ''
WHERE `id_panitia` = '3'
ERROR - 2026-01-01 22:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:42:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:44:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:46:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 22:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:04:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:08:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:47 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 72
ERROR - 2026-01-01 23:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:09:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 72
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:12:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:13:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:48:28 --> Severity: Warning --> Undefined variable $gurus D:\wwwroot\server.id\akm\application\views\cbt\jadwal\data.php 72
ERROR - 2026-01-01 23:55:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:55:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:55:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:57:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:57:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:57:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:57:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:57:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:58:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:58:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:58:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:58:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-01 23:59:59 --> 404 Page Not Found: Assets/plugins
