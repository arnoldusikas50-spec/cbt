<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-02 00:00:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:00:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:02:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:02:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:02:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:03:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:03:41 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 00:04:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:04:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:04:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:05:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:05:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:05:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:06:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:10:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:10:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:10:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:10:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:10:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:12:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:12:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:15:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:15:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:15:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:15:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:15:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:15:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:33:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:34:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:35:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:36:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:38:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:39:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:40:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:40:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 00:41:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:25:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:33:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:34:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:35:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 01:36:10 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 07:47:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:03:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:03:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:03:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:03:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:03:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:03:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:05:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:06:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:06:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:06:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:06:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:07:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:07:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:15:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:15:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 08:27:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:01:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:03:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:03:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:03:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:03:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:04:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:04:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:04:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:04:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:04:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:04:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:09:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:10:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:10:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:10:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:10:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:16:05 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:17:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:17:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:17:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:17:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:22:11 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:23:14 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:24:17 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:24:27 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:24:46 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:24:49 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:25:30 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:26:15 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:27:17 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:28:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:28:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:28:30 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:28:50 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:30:28 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:30:56 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:31:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:31:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:32:29 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:32:50 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:33:33 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:33:39 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:34:01 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:34:09 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:34:40 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:37:05 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:39:15 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:41:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:41:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:44:00 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:44:11 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:52:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:54:13 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 09:56:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:56:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:56:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:56:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:56:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 09:56:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:00:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:00:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:47:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:47:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:47:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:47:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:57 --> 404 Page Not Found: 20250393/index
ERROR - 2026-01-02 10:51:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:51:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:07 --> 404 Page Not Found: 20250393/index
ERROR - 2026-01-02 10:52:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 10:52:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:06:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:53:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:53:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:53:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:53:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 11:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 12:33:59 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 12:34:47 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 12:35:55 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 12:37:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 12:42:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:03:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:05:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:05:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:07:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:08:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:09:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:11:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:13:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:14:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:14:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:16:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:16:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:16:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:16:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:21:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:29:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:59:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:59:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 13:59:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:00:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:00:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:02:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:03:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:03:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:03:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:03:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:03:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:03:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:06:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:06:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:08:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:09:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:10:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:10:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:10:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:16:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:16:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:16:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:19:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:20:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:21:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:23:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:24:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:25:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:26:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:28:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:29:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:29:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:31:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:32:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:32:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 14:34:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 15:42:05 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 16:27:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:27:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:28:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:30:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:30:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:30:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:30:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:30:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:32:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:36:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:37:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:37:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:38:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:38:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:40:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:41:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:42:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:43:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:43:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:44:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:44:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:47:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:48:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:49:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:49:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:15 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:17 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:22 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:35 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:38 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:41 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:51 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:49:55 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:49:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:50:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:50:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:50:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 781
ERROR - 2026-01-02 16:50:46 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1227
ERROR - 2026-01-02 16:50:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 16:50:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:52:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:54:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:55:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:56:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:56:14 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 16:56:19 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 16:56:22 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 16:58:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:59:01 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 16:59:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 16:59:14 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 16:59:17 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:01:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:01:57 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:02:00 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:02:02 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:02:07 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:04:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:04:56 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:04:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:36 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 17:05:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:05:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:29 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 17:06:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:06:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:08 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 17:07:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:23 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 17:07:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:31 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:07:43 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:07:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:07:49 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:07:53 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 679
ERROR - 2026-01-02 17:09:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:09:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:09:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:09:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:09:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:09:57 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:06 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:09 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:10 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:11 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:12 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:13 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:27 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:10:28 --> Severity: Compile Error --> Cannot redeclare MY_Controller::processNilaiPg() D:\wwwroot\server.id\akm\application\core\MY_Controller.php 2940
ERROR - 2026-01-02 17:14:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:14:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:14:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:14:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:15:03 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 630
ERROR - 2026-01-02 17:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:15:11 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 630
ERROR - 2026-01-02 17:15:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:18:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:18:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:21:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:21:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:21:44 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 640
ERROR - 2026-01-02 17:22:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:22:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:23:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:23:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:23:15 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 640
ERROR - 2026-01-02 17:23:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:23:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:32:59 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:34:25 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:34:34 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:34:36 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:36:24 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:43:10 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:44:24 --> Severity: error --> Exception: array_column(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 641
ERROR - 2026-01-02 17:46:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:46:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:46:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:46:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:47:01 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 690
ERROR - 2026-01-02 17:53:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:53:35 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 690
ERROR - 2026-01-02 17:53:38 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 690
ERROR - 2026-01-02 17:54:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 17:54:27 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 690
ERROR - 2026-01-02 17:54:30 --> Severity: error --> Exception: array_values(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 690
ERROR - 2026-01-02 18:02:16 --> 404 Page Not Found: Cbtnilai/uploads
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:04:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:05:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:08:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:18:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:29 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1246
ERROR - 2026-01-02 18:18:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 800
ERROR - 2026-01-02 18:18:32 --> Severity: error --> Exception: array_shift(): Argument #1 ($array) must be of type array, stdClass given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1246
ERROR - 2026-01-02 18:18:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 18:18:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:21:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:32:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:33:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:34:19 --> Query error: Unknown column 'cbt_bank_soal.jml_urutan' in 'field list' - Invalid query: SELECT `cbt_bank_soal`.`id_bank`, `cbt_bank_soal`.`bank_kode`, `cbt_bank_soal`.`bank_kelas`, `cbt_bank_soal`.`opsi`, `cbt_bank_soal`.`jml_soal`, `cbt_bank_soal`.`tampil_pg`, `cbt_bank_soal`.`bobot_pg`, `cbt_bank_soal`.`jml_kompleks`, `cbt_bank_soal`.`tampil_kompleks`, `cbt_bank_soal`.`bobot_kompleks`, `cbt_bank_soal`.`jml_jodohkan`, `cbt_bank_soal`.`tampil_jodohkan`, `cbt_bank_soal`.`bobot_jodohkan`, `cbt_bank_soal`.`jml_isian`, `cbt_bank_soal`.`tampil_isian`, `cbt_bank_soal`.`bobot_isian`, `cbt_bank_soal`.`jml_esai`, `cbt_bank_soal`.`tampil_esai`, `cbt_bank_soal`.`bobot_esai`, `cbt_bank_soal`.`jml_urutan`, `cbt_bank_soal`.`tampil_urutan`, `cbt_bank_soal`.`bobot_urutan`, `cbt_bank_soal`.`jml_cloze`, `cbt_bank_soal`.`tampil_cloze`, `cbt_bank_soal`.`bobot_cloze`, `cbt_bank_soal`.`id_tp`, `cbt_bank_soal`.`id_smt`, `cbt_bank_soal`.`soal_agama`, `cbt_bank_soal`.`id_bank`, `cbt_bank_soal`.`bank_mapel_id`, `cbt_bank_soal`.`bank_guru_id`
FROM `cbt_bank_soal`
WHERE id_tp =  4
AND id_smt =  1
AND `cbt_bank_soal`.`id_bank` IN('861')
ERROR - 2026-01-02 18:34:25 --> Query error: Unknown column 'cbt_bank_soal.jml_urutan' in 'field list' - Invalid query: SELECT `cbt_bank_soal`.`id_bank`, `cbt_bank_soal`.`bank_kode`, `cbt_bank_soal`.`bank_kelas`, `cbt_bank_soal`.`opsi`, `cbt_bank_soal`.`jml_soal`, `cbt_bank_soal`.`tampil_pg`, `cbt_bank_soal`.`bobot_pg`, `cbt_bank_soal`.`jml_kompleks`, `cbt_bank_soal`.`tampil_kompleks`, `cbt_bank_soal`.`bobot_kompleks`, `cbt_bank_soal`.`jml_jodohkan`, `cbt_bank_soal`.`tampil_jodohkan`, `cbt_bank_soal`.`bobot_jodohkan`, `cbt_bank_soal`.`jml_isian`, `cbt_bank_soal`.`tampil_isian`, `cbt_bank_soal`.`bobot_isian`, `cbt_bank_soal`.`jml_esai`, `cbt_bank_soal`.`tampil_esai`, `cbt_bank_soal`.`bobot_esai`, `cbt_bank_soal`.`jml_urutan`, `cbt_bank_soal`.`tampil_urutan`, `cbt_bank_soal`.`bobot_urutan`, `cbt_bank_soal`.`jml_cloze`, `cbt_bank_soal`.`tampil_cloze`, `cbt_bank_soal`.`bobot_cloze`, `cbt_bank_soal`.`id_tp`, `cbt_bank_soal`.`id_smt`, `cbt_bank_soal`.`soal_agama`, `cbt_bank_soal`.`id_bank`, `cbt_bank_soal`.`bank_mapel_id`, `cbt_bank_soal`.`bank_guru_id`
FROM `cbt_bank_soal`
WHERE id_tp =  4
AND id_smt =  1
AND `cbt_bank_soal`.`id_bank` IN('602')
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 806
ERROR - 2026-01-02 18:37:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 18:45:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:46:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:46:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:46:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:47:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:51:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:56:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:57:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:57:12 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:57:15 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:57:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:57:23 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:57:30 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:57:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:58:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:11 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:12 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:15 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:24 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:30 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:58:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:59:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 18:59:27 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:59:29 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 18:59:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:00:06 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:00:09 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:00:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:01:04 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:01:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:01:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:03:46 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:03:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:09:00 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:10:29 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:10:35 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:10:36 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:10:37 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:10:50 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:11:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:12:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:12:48 --> 404 Page Not Found: Cbtsiswa/dashboard
ERROR - 2026-01-02 19:13:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:13:35 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\wwwroot\server.id\akm\application\controllers\Cbtsiswa.php 1604
ERROR - 2026-01-02 19:15:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:21:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:21:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:24:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:42:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:45:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:47:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:47:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:47:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:52:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 19:56:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:44 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1627
ERROR - 2026-01-02 20:16:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 20:16:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:16:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:16:59 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1627
ERROR - 2026-01-02 20:16:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1627
ERROR - 2026-01-02 20:17:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 20:17:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:17:16 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1627
ERROR - 2026-01-02 20:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\system\core\Common.php 565
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:53 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:22:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:24:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:24:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:25:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:25:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:25:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:26:30 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-02 20:26:30 --> 404 Page Not Found: 20240358/index
ERROR - 2026-01-02 20:26:30 --> 404 Page Not Found: 20250393/index
ERROR - 2026-01-02 20:27:00 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-02 20:27:00 --> 404 Page Not Found: 20250393/index
ERROR - 2026-01-02 20:27:00 --> 404 Page Not Found: 20240358/index
ERROR - 2026-01-02 20:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1262
ERROR - 2026-01-02 20:28:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:29:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:29:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:29:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:29:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:29:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:30:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:30:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:25 --> 404 Page Not Found: Assets/app
ERROR - 2026-01-02 20:30:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:30:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:31:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:31:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:31:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:31:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:32:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:32:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:34:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:34:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:35:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:35:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:35:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:35:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:36:51 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-02 20:37:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:37:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:37:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:37:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:37:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:41:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:41:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 20:46:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1264
ERROR - 2026-01-02 20:48:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:48:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:48:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:49:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:49:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:50:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1274
ERROR - 2026-01-02 20:51:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:52:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:55:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 20:56:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 21:23:55 --> 404 Page Not Found: 20240356/index
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:19:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:20:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:20:50 --> Severity: Warning --> Attempt to read property "jadwal" on false D:\wwwroot\server.id\akm\application\controllers\Cbtrekap.php 1148
ERROR - 2026-01-02 22:20:50 --> Severity: error --> Exception: Attempt to assign property "jadwal" on false D:\wwwroot\server.id\akm\application\controllers\Cbtrekap.php 1148
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:25:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:26:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:28:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:29:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:30:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:31:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> foreach() argument must be of type array|object, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1941
ERROR - 2026-01-02 22:34:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\wwwroot\server.id\akm\system\core\Exceptions.php:272) D:\wwwroot\server.id\akm\application\core\MY_Controller.php 126
ERROR - 2026-01-02 22:36:36 --> Severity: error --> Exception: array_merge(): Argument #6 must be of type array, string given D:\wwwroot\server.id\akm\application\core\MY_Controller.php 1878
ERROR - 2026-01-02 22:47:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-02 22:47:27 --> 404 Page Not Found: Assets/plugins
