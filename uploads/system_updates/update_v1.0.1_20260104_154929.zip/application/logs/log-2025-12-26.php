<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-26 08:55:40 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 08:56:26 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 08:56:32 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 08:56:42 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 08:59:24 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 09:05:09 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 09:48:57 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:56:02 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:56:57 --> 404 Page Not Found: Cbtguru/index
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 133
ERROR - 2025-12-26 09:57:04 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object D:\wwwroot\server.id\akm\application\views\cbt\rpm\data.php 134
ERROR - 2025-12-26 11:42:15 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 11:44:44 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 15:11:21 --> Query error: Unknown column 'api_key' in 'field list' - Invalid query: UPDATE `master_guru` SET `nip` = '1746765666130182', `nama_guru` = 'Ester Snaes T, S.Pd', `email` = '', `jenis_kelamin` = 'L', `no_hp` = '', `agama` = 'Protestan', `no_ktp` = '', `tempat_lahir` = '', `tgl_lahir` = NULL, `alamat_jalan` = '', `kecamatan` = '', `kabupaten` = '', `provinsi` = '', `kode_pos` = '0', `api_key` = 'sk-53adb42c3c6c4a38916d8f8b81d95182'
WHERE `id_guru` = '1'
ERROR - 2025-12-26 15:13:13 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 15:13:25 --> Query error: Unknown column 'api_key' in 'field list' - Invalid query: UPDATE `master_guru` SET `nip` = '1746765666130182', `nama_guru` = 'Ester Snaes T, S.Pd', `email` = '', `jenis_kelamin` = 'L', `no_hp` = '', `agama` = 'Protestan', `no_ktp` = '', `tempat_lahir` = '', `tgl_lahir` = NULL, `alamat_jalan` = '', `kecamatan` = '', `kabupaten` = '', `provinsi` = '', `kode_pos` = '0', `api_key` = 'AIzaSyDmhLjZCP05PinWjtOV6BbcokFrlG8CKds'
WHERE `id_guru` = '1'
ERROR - 2025-12-26 15:20:30 --> 404 Page Not Found: Cbtguru/index
ERROR - 2025-12-26 15:21:00 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 15:29:49 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 15:30:14 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 15:30:16 --> 404 Page Not Found: Assets/img
ERROR - 2025-12-26 20:46:10 --> 404 Page Not Found: Uploads/profile_guru
