<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-01-04 00:00:08 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:00:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:00:26 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:01:08 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:02:41 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:02:42 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:02:42 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:02:50 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:03:01 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:03:08 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:08 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:09 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:11 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:11 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:12 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:12 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:13 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:04:27 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:45 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:46 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:53 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:54 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:56 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:57 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:05:59 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:50 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:52 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:53 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:53 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:54 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:54 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:54 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:06:55 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:07:00 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:07:01 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:07:51 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:08:44 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:09:48 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:09:49 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:09:53 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:09:54 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:26 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:36 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:38 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:38 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:48 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:49 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:11:49 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:12:12 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:12:22 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:12:22 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:12:25 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:12:50 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:13:40 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 00:17:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:17:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:17:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:17:50 --> 404 Page Not Found: Auth/l
ERROR - 2026-01-04 00:18:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:18:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:18:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:18:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 00:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 02:26:35 --> Severity: Warning --> Attempt to read property "kkm_tunggal" on null D:\wwwroot\server.id\akm\application\views\members\guru\rapor\nilai\harian.php 168
ERROR - 2026-01-04 02:26:35 --> Severity: Warning --> Attempt to read property "kkm" on null D:\wwwroot\server.id\akm\application\views\members\guru\rapor\nilai\harian.php 169
ERROR - 2026-01-04 02:26:35 --> Severity: Warning --> Attempt to read property "kkm" on null D:\wwwroot\server.id\akm\application\views\members\guru\rapor\nilai\harian.php 187
ERROR - 2026-01-04 02:26:35 --> Severity: Warning --> Attempt to read property "bobot_ph" on null D:\wwwroot\server.id\akm\application\views\members\guru\rapor\nilai\harian.php 195
ERROR - 2026-01-04 02:57:37 --> Severity: Warning --> Undefined property: Sync::$session D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:37 --> Severity: error --> Exception: Call to a member function userdata() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:44 --> Severity: Warning --> Undefined property: Sync::$session D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:44 --> Severity: error --> Exception: Call to a member function userdata() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:49 --> Severity: Warning --> Undefined property: Sync::$session D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:49 --> Severity: error --> Exception: Call to a member function userdata() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:53 --> Severity: Warning --> Undefined property: Sync::$session D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:53 --> Severity: error --> Exception: Call to a member function userdata() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:59 --> Severity: Warning --> Undefined property: Sync::$session D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 02:57:59 --> Severity: error --> Exception: Call to a member function userdata() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 18
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Undefined variable $judul D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 9
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 11
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Attempt to read property "logo_kiri" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 11
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Undefined variable $user D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Attempt to read property "nama_lengkap" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Undefined variable $user D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Attempt to read property "jabatan" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 6
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Attempt to read property "logo_kiri" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 6
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 16
ERROR - 2026-01-04 03:07:13 --> Severity: Warning --> Attempt to read property "nama_aplikasi" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 16
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Undefined variable $judul D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 9
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 11
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Attempt to read property "logo_kiri" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 11
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Undefined variable $user D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Attempt to read property "nama_lengkap" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Undefined variable $user D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Attempt to read property "jabatan" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 6
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Attempt to read property "logo_kiri" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 6
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 16
ERROR - 2026-01-04 03:07:24 --> Severity: Warning --> Attempt to read property "nama_aplikasi" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 16
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Undefined variable $judul D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 9
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 11
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Attempt to read property "logo_kiri" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\_header.php 11
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Undefined variable $user D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Attempt to read property "nama_lengkap" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 17
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Undefined variable $user D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Attempt to read property "jabatan" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\navbar.php 18
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 6
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Attempt to read property "logo_kiri" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 6
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Undefined variable $setting D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 16
ERROR - 2026-01-04 03:08:05 --> Severity: Warning --> Attempt to read property "nama_aplikasi" on null D:\wwwroot\server.id\akm\application\views\_templates\dashboard\sidebar.php 16
ERROR - 2026-01-04 03:17:38 --> Query error: Table 'akm.sync_config' doesn't exist - Invalid query: INSERT INTO `sync_config` (`server_type`, `pusat_url`, `api_key`, `api_secret`, `auto_sync`, `sync_interval`, `sync_on_startup`, `server_id`) VALUES ('pusat', '', '', '', 0, '60', 1, 'd5535815-3ec0-474a-94eb-497954e5fb95')
ERROR - 2026-01-04 03:19:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:19:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:19:18 --> Query error: Table 'akm.sync_config' doesn't exist - Invalid query: INSERT INTO `sync_config` (`server_type`, `pusat_url`, `api_key`, `api_secret`, `auto_sync`, `sync_interval`, `sync_on_startup`, `server_id`) VALUES ('pusat', '', '', '', 0, '60', 1, '4b8f7b90-eb7b-4576-948e-eaed7d109525')
ERROR - 2026-01-04 03:19:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:19:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:20:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:20:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:21:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:21:44 --> 404 Page Not Found: Assets/img
ERROR - 2026-01-04 03:24:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2026-01-04 03:43:16 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:43:16 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:43:33 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:43:33 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:43:34 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:43:34 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:43:55 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:43:55 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:46:32 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:46:32 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:46:53 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:46:53 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:47:52 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:47:52 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 90
ERROR - 2026-01-04 03:53:06 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:53:06 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:53:37 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:53:37 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:54:49 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:54:49 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:56:23 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:56:23 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:56:43 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:56:43 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:58:10 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:58:10 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:58:23 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:58:23 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:58:51 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:58:51 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 03:59:42 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 03:59:42 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 04:08:35 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 04:08:35 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 04:10:17 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 04:10:17 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 04:10:21 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 04:10:21 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 04:22:37 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 04:22:37 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 04:24:57 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 04:24:57 --> Severity: error --> Exception: Call to a member function get_where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 103
ERROR - 2026-01-04 04:47:56 --> Severity: Warning --> Undefined variable $ujian_box D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 66
ERROR - 2026-01-04 04:47:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 66
ERROR - 2026-01-04 04:47:56 --> Severity: Warning --> Undefined variable $token D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 92
ERROR - 2026-01-04 04:47:56 --> Severity: Warning --> Attempt to read property "token" on null D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 92
ERROR - 2026-01-04 04:47:56 --> Severity: Warning --> Undefined variable $jadwal_kbm D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 125
ERROR - 2026-01-04 04:47:56 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 125
ERROR - 2026-01-04 04:48:23 --> Severity: Warning --> Undefined variable $ujian_box D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 66
ERROR - 2026-01-04 04:48:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 66
ERROR - 2026-01-04 04:48:23 --> Severity: Warning --> Undefined variable $token D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 92
ERROR - 2026-01-04 04:48:23 --> Severity: Warning --> Attempt to read property "token" on null D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 92
ERROR - 2026-01-04 04:48:23 --> Severity: Warning --> Undefined variable $jadwal_kbm D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 125
ERROR - 2026-01-04 04:48:23 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given D:\wwwroot\server.id\akm\application\views\members\sekolah\dashboard.php 125
ERROR - 2026-01-04 05:11:08 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:11:08 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:36:20 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:36:20 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:37:31 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:37:31 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:54:39 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:54:39 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:54:40 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:54:40 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:56:18 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:56:18 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:56:46 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:56:46 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:56:48 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:56:48 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:57:49 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:57:49 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 05:59:47 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 05:59:47 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:00:38 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:00:38 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:03:27 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:03:27 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:04:16 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:04:16 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:04:24 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:04:24 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:04:50 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:04:50 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:05:05 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:05:05 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:05:05 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:05:05 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:05:06 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:05:06 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:05:16 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:05:16 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:13:31 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:13:31 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:13:46 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:13:46 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:16:51 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:16:51 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:16:56 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:16:56 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:16:59 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:16:59 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:17:00 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:17:00 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 06:17:35 --> Severity: Warning --> Undefined property: Api_sync::$db D:\wwwroot\server.id\akm\system\core\Model.php 74
ERROR - 2026-01-04 06:17:35 --> Severity: error --> Exception: Call to a member function where() on null D:\wwwroot\server.id\akm\application\models\Sync_model.php 104
ERROR - 2026-01-04 07:06:29 --> 404 Page Not Found: Download_batch/index
ERROR - 2026-01-04 07:17:26 --> Query error: Table 'akm.ref_jurusan' doesn't exist - Invalid query: SHOW COLUMNS FROM `ref_jurusan`
ERROR - 2026-01-04 07:22:02 --> Query error: Table 'akm.ref_jurusan' doesn't exist - Invalid query: SHOW COLUMNS FROM `ref_jurusan`
ERROR - 2026-01-04 07:22:21 --> Query error: Table 'akm.ref_jurusan' doesn't exist - Invalid query: SHOW COLUMNS FROM `ref_jurusan`
ERROR - 2026-01-04 07:22:42 --> Query error: Table 'akm.ref_jurusan' doesn't exist - Invalid query: SHOW COLUMNS FROM `ref_jurusan`
ERROR - 2026-01-04 13:15:13 --> Severity: Warning --> Undefined variable $config D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 99
ERROR - 2026-01-04 13:15:13 --> Severity: Warning --> Undefined variable $pending_records D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:15:13 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:15:13 --> Severity: Warning --> Undefined variable $queue_count D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:15:13 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:15:13 --> Severity: Warning --> Undefined variable $last_sync D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 191
ERROR - 2026-01-04 13:15:13 --> Severity: Warning --> Undefined variable $is_pusat D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 206
ERROR - 2026-01-04 13:15:34 --> Severity: Warning --> Undefined variable $config D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 99
ERROR - 2026-01-04 13:15:34 --> Severity: Warning --> Undefined variable $pending_records D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:15:34 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:15:34 --> Severity: Warning --> Undefined variable $queue_count D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:15:34 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:15:34 --> Severity: Warning --> Undefined variable $last_sync D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 191
ERROR - 2026-01-04 13:15:34 --> Severity: Warning --> Undefined variable $is_pusat D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 206
ERROR - 2026-01-04 13:16:18 --> Severity: Warning --> Undefined variable $config D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 99
ERROR - 2026-01-04 13:16:18 --> Severity: Warning --> Undefined variable $pending_records D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:16:18 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:16:18 --> Severity: Warning --> Undefined variable $queue_count D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:16:18 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:16:18 --> Severity: Warning --> Undefined variable $last_sync D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 191
ERROR - 2026-01-04 13:16:18 --> Severity: Warning --> Undefined variable $is_pusat D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 206
ERROR - 2026-01-04 13:16:19 --> Severity: Warning --> Undefined variable $config D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 99
ERROR - 2026-01-04 13:16:19 --> Severity: Warning --> Undefined variable $pending_records D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:16:19 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:16:19 --> Severity: Warning --> Undefined variable $queue_count D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:16:19 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:16:19 --> Severity: Warning --> Undefined variable $last_sync D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 191
ERROR - 2026-01-04 13:16:19 --> Severity: Warning --> Undefined variable $is_pusat D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 206
ERROR - 2026-01-04 13:16:50 --> Severity: Warning --> Undefined variable $config D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 99
ERROR - 2026-01-04 13:16:50 --> Severity: Warning --> Undefined variable $pending_records D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:16:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 160
ERROR - 2026-01-04 13:16:50 --> Severity: Warning --> Undefined variable $queue_count D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:16:50 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 176
ERROR - 2026-01-04 13:16:50 --> Severity: Warning --> Undefined variable $last_sync D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 191
ERROR - 2026-01-04 13:16:50 --> Severity: Warning --> Undefined variable $is_pusat D:\wwwroot\server.id\akm\application\views\admin\sync\index.php 206
ERROR - 2026-01-04 15:03:26 --> Severity: Warning --> Undefined property: Sync::$Update_manager D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:03:26 --> Severity: error --> Exception: Call to a member function get_backups() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:05:35 --> Severity: Warning --> Undefined property: Sync::$Update_manager D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:05:35 --> Severity: error --> Exception: Call to a member function get_backups() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:06:13 --> Severity: Warning --> Undefined property: Sync::$Update_manager D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:06:13 --> Severity: error --> Exception: Call to a member function get_backups() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:06:16 --> Severity: Warning --> Undefined property: Sync::$Update_manager D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:06:16 --> Severity: error --> Exception: Call to a member function get_backups() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:06:19 --> Severity: Warning --> Undefined property: Sync::$Update_manager D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:06:19 --> Severity: error --> Exception: Call to a member function get_backups() on null D:\wwwroot\server.id\akm\application\controllers\Sync.php 1225
ERROR - 2026-01-04 15:16:23 --> 404 Page Not Found: Sync/manage_update
ERROR - 2026-01-04 15:28:56 --> Severity: error --> Exception: explode(): Argument #2 ($string) must be of type string, array given D:\wwwroot\server.id\akm\application\controllers\Dbmanager.php 46
ERROR - 2026-01-04 15:29:27 --> Severity: error --> Exception: explode(): Argument #2 ($string) must be of type string, array given D:\wwwroot\server.id\akm\application\controllers\Dbmanager.php 46
ERROR - 2026-01-04 15:32:02 --> Severity: error --> Exception: explode(): Argument #2 ($string) must be of type string, array given D:\wwwroot\server.id\akm\application\controllers\Dbmanager.php 46
ERROR - 2026-01-04 15:39:30 --> Severity: error --> Exception: explode(): Argument #2 ($string) must be of type string, array given D:\wwwroot\server.id\akm\application\controllers\Dbmanager.php 46
ERROR - 2026-01-04 15:43:48 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:43:56 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:44:22 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:44:33 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:44:39 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:44:39 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:44:48 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
ERROR - 2026-01-04 15:44:53 --> Severity: Compile Error --> Cannot redeclare Sync::manage_updates() D:\wwwroot\server.id\akm\application\controllers\Sync.php 1814
